public class Main {

    public static void main(String[] args) {
        int[][] myArray1;
        int[][] myArray2;

        do {
            myArray1 = Matrix.initDoubleMatrix();
            myArray2 = Matrix.initDoubleMatrix();
        } while (!Matrix.compareDoubleMatrices(myArray1, myArray2));

        Matrix.maxSameElements(myArray1, myArray2);
    }
}
